public class Percolation {
	private boolean[] grid;
	private WeightedQuickUnionUF model;
	private WeightedQuickUnionUF full;
	private int N;
	
	public Percolation(int N) {
		if (N <= 0) throw new IllegalArgumentException(); 
		this.N = N;
		grid = new boolean[N*N+2];
		model = new WeightedQuickUnionUF(N*N+2);
		full = new WeightedQuickUnionUF(N*N+2);
		/*for (int i = 1; i <= N; i++){
			model.union(i, 0);
			model.union(N*N-i+1, N*N+1);
		}*/				
	}

	public void open(int i, int j) { 
		validateIndex(i, j);
		if (isOpen(i, j)) return;
		grid[convertIndex(i, j)] = true; 
		if (i == 1) { model.union(0, convertIndex(i, j)); full.union(0, convertIndex(i, j)); }
		if (i == N) { model.union(N*N+1, convertIndex(i, j)); }
		if (j != 1 && isOpen(i, j-1)) { model.union(convertIndex(i, j), convertIndex(i, j-1)); full.union(convertIndex(i, j), convertIndex(i, j-1)); }	//left cell
		if (j != N && isOpen(i, j+1)) { model.union(convertIndex(i, j), convertIndex(i, j+1)); full.union(convertIndex(i, j), convertIndex(i, j+1)); }	//right cell
		if (i != 1 && isOpen(i-1, j)) { model.union(convertIndex(i, j), convertIndex(i-1, j)); full.union(convertIndex(i, j), convertIndex(i-1, j)); }	//up cell
		if (i != N && isOpen(i+1, j)) { model.union(convertIndex(i, j), convertIndex(i+1, j)); full.union(convertIndex(i, j), convertIndex(i+1, j)); }	//down cell
	}
	
	public boolean isOpen(int i, int j) { 
		validateIndex(i, j);
		return grid[convertIndex(i, j)]; 
	}
	
	public boolean isFull(int i, int j) { 
		validateIndex(i, j);
		return full.connected(0, convertIndex(i, j)); 
	}
	
	public boolean percolates() { 	
		return  model.connected(0, N*N+1);
	}	
	
	private void validateIndex(int i, int j) {
		if (i <= 0 || j <= 0 || i > N || j > N) throw new IndexOutOfBoundsException();
	}
	
	private int convertIndex(int i, int j) {
		validateIndex(i, j);
		return (i-1) * N + j;
		//return	(i - 1) * N + (j - 1);
	}
	
}
